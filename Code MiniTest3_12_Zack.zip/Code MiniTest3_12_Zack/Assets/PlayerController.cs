﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
public class PlayerController : MonoBehaviour
{
  
   
    float moveSpeed = 7.0f;
    public Animator anim;
    private int ballcount;
   
    
    // Start is called before the first frame update
    void Start()
    {
       
        
    }

    // Update is called once per frame
    void Update()
    {
        
        if (Input.GetKey(KeyCode.W))
        {
            transform.rotation = Quaternion.Euler(0, 0, 0);
            StartRun();
            anim.SetBool("IsRun", true);
            anim.SetFloat("startRun", 1);
        }
        else if(Input.GetKey(KeyCode.S))
        {
            transform.rotation = Quaternion.Euler(0, 180, 0);
            StartRun();
            anim.SetBool("IsRun", true);
            anim.SetFloat("startRun", 1);
        }
        else if (Input.GetKey(KeyCode.D))
        {
            transform.rotation = Quaternion.Euler(0, 90, 0);
            StartRun();
            anim.SetBool("IsRun", true);
            anim.SetFloat("startRun", 1);
        }
        else if (Input.GetKey(KeyCode.A))
        {
            transform.rotation = Quaternion.Euler(0, -90, 0);
            StartRun();
            anim.SetBool("IsRun", true);
            anim.SetFloat("startRun", 1);
        }
        else if(Input.GetKeyUp(KeyCode.W)|| Input.GetKeyUp(KeyCode.A)|| Input.GetKeyUp(KeyCode.S)|| Input.GetKeyUp(KeyCode.D))
        {
            anim.SetBool("IsRun", false);
            anim.SetFloat("startRun", 0);
        }
       
      
        
        
    }
    void StartRun()
    {
        transform.Translate(Vector3.forward * Time.deltaTime * moveSpeed);
    }
    private void OnTriggerEnter(Collider other)
    {
        
        if(other.gameObject.CompareTag("Ball"))
        {
            ballcount++;
            Destroy(other.gameObject);
        }
    }
    private void OnCollisionEnter(Collision collision)
    {
        if(gameObject.CompareTag("Box"))
        {
            SceneManager.LoadScene("Win");
        }
    }
}
